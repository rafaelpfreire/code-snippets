#include <stdio.h>

int main()
{

	int i = 10;
	int j = 20;

	i += j;
	i -= j;
	i *= j;
	i /= j;

	return 0;
}
