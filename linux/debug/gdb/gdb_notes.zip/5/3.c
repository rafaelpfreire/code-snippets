/*
	Printing string using x
	p &msg
	x/s address
*/

#include <stdio.h>

int main()
{
	char msg[] = "Hello World";

	printf("Message:%s\n", msg);
	return 0;
}
