int main()
{
    int a[] = {1,2,3};
    return 0;
}
