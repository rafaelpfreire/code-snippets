int main()
{
  int i = 1337;
  return 0;
}
