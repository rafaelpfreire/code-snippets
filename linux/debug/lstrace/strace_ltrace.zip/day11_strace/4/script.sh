#!/bin/bash
echo "hello world"
id -urn
