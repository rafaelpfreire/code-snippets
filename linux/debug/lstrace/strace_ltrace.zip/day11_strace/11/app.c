#include <stdio.h>
int main() 
{
	printf("hello world Learning Linux is very easy\n");
	printf("bye world\n");
	return 0;
}

