#include <stdio.h>

int main()
{
	printf("Hello Linux learning is easy with more examples\n");
	return 0;
}
