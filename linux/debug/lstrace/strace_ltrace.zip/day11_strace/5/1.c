#include <stdio.h>
#include <unistd.h>

int main()
{
	printf("Hello World\n");
	sleep(2);
	printf("Bye World\n");
	return 0;
}
