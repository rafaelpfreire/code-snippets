#include <stdio.h>
int main() 
{
	int i = 0;
	printf("hello world Learning Linux is very easy\n");
	while(1) {
		i++;
		printf("Hello %d time\n", i);
		sleep(2);
	}
	return 0;
}

