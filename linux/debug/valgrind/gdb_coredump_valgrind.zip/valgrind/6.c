#include <stdio.h>

int main()
{
	int x;

	if (x)
		printf("true case: x=%d\n", x);
	else
		printf("false case\n");

	return 0;
}
